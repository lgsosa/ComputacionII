# Computación II - Ingeniería Informática

**Nombre:** Luciana  
**Expectativas sobre la materia:**  
- Espero poder aprender mucho sobre la gestión de proyectos con Git y el uso eficiente de herramientas de desarrollo en sistemas Unix/Linux. Me gustaría aplicar estos conocimientos en proyectos reales y mejorar mis habilidades en el trabajo en equipo dentro de entornos de software.  

**Intereses en programación:**  
- Me gusta la programación por su versatilidad y el impacto que puede tener en la vida cotidiana. Disfruto resolviendo problemas complejos y me interesa el desarrollo de software eficiente, especialmente en áreas como la automatización y la optimización de procesos.  

**Hobbies:**  
- Me gusta ir al gimnasio, aprender idiomas y leer cosas interesantes, especialmente temas relacionados con tecnología, ciencia y desarrollo personal.  